﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListCapacityDemo
{
    class IntCapacityRecord
    {
        public int ListCount { get; set; }
        public int ListCapacity { get; set; }
    }
}
