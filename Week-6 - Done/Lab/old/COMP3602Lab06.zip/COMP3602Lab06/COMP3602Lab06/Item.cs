﻿// Monika Szucs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace COMP3602Lab06
{
    abstract class Item : IComparable<Item>
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public float Price { get; set; }
        public string Sku { get; }

        public DateTime? DateTime { get; }

        public Item(int id, string description, string sku, float price, DateTime? dateTime)
        {
            Id = id;
            Description = description;
            Price = price;
            Sku = sku;
            DateTime = dateTime;
        }

        public abstract string[] toString();

        // Organizing items by price
        public int CompareTo(Item other)
        {
            return -Price.CompareTo(other.Price);
        }
    }
}
