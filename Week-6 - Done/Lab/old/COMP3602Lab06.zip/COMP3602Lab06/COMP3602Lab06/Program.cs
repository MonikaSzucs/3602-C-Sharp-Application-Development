﻿// Monika Szucs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP3602Lab06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ConsolePrinter.printNaturalOrder();
            ItemList products = ProductRepository.GetProducts();
            ConsolePrinter.PrintProducts(products);
            Console.ReadKey();

            ConsolePrinter.printSortedOrder();
            ItemList productsTwo = ProductRepository.GetProducts();
            productsTwo.Sort();
            ConsolePrinter.PrintProducts(productsTwo);
            Console.ReadKey();
        }
    }
}
