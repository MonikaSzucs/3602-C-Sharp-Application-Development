﻿// Monika Szucs
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP3602Lab06
{
    class GroceryItem : Item
    {
        public DateTime? ExpirationDate { get; }

        public GroceryItem(int id, string description, string sku, float price, DateTime? expirationDate) : base(id, description, sku, price, expirationDate)
        {
            ExpirationDate = expirationDate;
        }

        public override string[] toString()
        {
            // output -> desc, price, expiry date
            string[] data = new string[4];

            data[0] = this.Description;
            data[1] = this.Price.ToString();
            data[3] = this.ExpirationDate == DateTime.Value ? "<Never>" : this.ExpirationDate.ToString();

            return data;
        }
    }
}
