﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP3602Lab05
{
    internal class SalaryEmployee
    {
        public decimal Salary { get; }

        public SalaryEmployee(decimal salary)
        {
            SalaryEmployee = salary;
        }

        public override decimal CalculatePay()
        {
            return Salary;
        }

        
    }
}
