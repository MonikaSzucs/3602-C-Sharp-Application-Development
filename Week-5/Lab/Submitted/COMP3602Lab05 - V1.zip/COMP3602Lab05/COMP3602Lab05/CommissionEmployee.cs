﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP3602Lab05
{
    internal class CommissionEmployee
    {
        private decimal Sales { get; }
        private double CommissionRate { get; }

        public CommissionEmployee(decimal sales, double commissionRate)
        {
            Sales = sales;
            CommissionRate = commissionRate;
        }

        public override decimal CalculatePay()
        {
            return Sales * (decimal) CommissionRate;
        }
    }
}
