﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP3602Lab05
{
    class Vendor
    {
        public decimal TotalInvoices { get; }

        public Vendor(decimal totalInvoices)
        {
            TotalInvoices = totalInvoices;
        }
        public decimal CalculatePay()
        {
            return TotalInvoices;
        }
    }
}
